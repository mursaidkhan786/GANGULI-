---
name: Ganguli Heritage Civic
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#404941'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#717970'
  outline-variant: '#c0c9be'
  surface-tint: '#2e6a41'
  primary: '#003b1b'
  on-primary: '#ffffff'
  primary-container: '#14532d'
  on-primary-container: '#87c695'
  inverse-primary: '#96d5a3'
  secondary: '#a73a00'
  on-secondary: '#ffffff'
  secondary-container: '#fd651e'
  on-secondary-container: '#571a00'
  tertiary: '#003a19'
  on-tertiary: '#ffffff'
  tertiary-container: '#005427'
  on-tertiary-container: '#7cc88c'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#b1f2be'
  primary-fixed-dim: '#96d5a3'
  on-primary-fixed: '#00210d'
  on-primary-fixed-variant: '#12512c'
  secondary-fixed: '#ffdbce'
  secondary-fixed-dim: '#ffb599'
  on-secondary-fixed: '#370e00'
  on-secondary-fixed-variant: '#7f2b00'
  tertiary-fixed: '#a6f4b5'
  tertiary-fixed-dim: '#8bd79b'
  on-tertiary-fixed: '#00210b'
  on-tertiary-fixed-variant: '#005226'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Manrope
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Manrope
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Manrope
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Manrope
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 30px
    letterSpacing: 0em
  headline-sm:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: 0em
  title-md:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0.005em
  body-lg:
    fontFamily: Source Sans 3
    fontSize: 17px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: 0em
  body-md:
    fontFamily: Source Sans 3
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0.01em
  body-sm:
    fontFamily: Source Sans 3
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Manrope
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-tablet: 1.5rem
  gutter-desktop: 2rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system establishes a civic-grade, hyper-local digital ecosystem for rural and peri-urban pride. Balancing institutional authority with cultural warmth, the visual language rejects chaotic village portal tropes in favor of an orderly, modern grotesque architecture. The tone communicates permanence, transparency, communal trust, and administrative efficiency. 

The aesthetic is grounded in **Modern Civic Minimalism** infused with refined Mithila folk dignity:
- **Visual Stature:** Stately deep emeralds (#14532D) evoke agrarian fertility and panchayat authority, counterbalanced by vibrant saffron accents (#EA580C) representing celebratory energy, auspicious enterprise, and urgent public alerts.
- **Audience & Context:** Citizens of Ganguli (Benipatti, Madhubani) spanning multigenerational farmers, migrant diaspora tracking home developments, local merchants, and administrative ward members. The interface prioritizes high legibility under harsh outdoor sunlight, zero visual clutter, and seamless visual comprehension across Hindi, Maithili, and English.
- **Cultural Texture:** Instead of decorative folk motifs that degrade digital performance, cultural resonance is conveyed through precise color harmonies (emerald, earthen saffron, chalk white) and clean, pill-shaped tags reminiscent of stamped civic certificates and village milestones.

## Colors

The palette establishes an authoritative hierarchy rooted in natural earth tones and high-visibility state cues.

### Primary & Dark Greens
- **Primary Base (`#14532D`):** Deep Forest Emerald. Anchor color for headers, dominant interactive buttons, top app bars, and high-level civic navigation. Imparts administrative integrity and institutional calm.
- **Primary Interactive (`#166534`):** Mid-tone Emerald. Reserved for hover states, pressed containers, focused boundaries, and secondary active fills.

### Vibrant Saffron & Orange
- **Accent Primary (`#EA580C`):** Terracotta Saffron. Used for critical call-to-actions (e.g., grievance escalation, festival announcements, bill payments), urgent alerts, and active indicators.
- **Accent Vibrant (`#F97316`):** Vivid Marigold. Used selectively for notification pips, pending action badges, and dynamic progress bar fills.

### Surface & Neutral System
- **Canvas Base (`#F8FAFC`):** Slate Tint White. Reduces retinal glare compared to harsh pure white while preserving crisp separation outdoors.
- **Surface Elevation 1 (`#FFFFFF`):** Pure Chalk White. Modular cards, dialogs, sheets, and bottom sheets.
- **Text & Structure Hierarchy:**
  - **Headings & High Contrast Text:** `#0F172A` (Slate 900)
  - **Body Copy:** `#334155` (Slate 700)
  - **Muted & Metadata:** `#64748B` (Slate 500)
  - **Borders & Dividers:** `#E2E8F0` (Slate 200)

## Typography

The typographic hierarchy solves for complex multi-script legibility (Devanagari alongside Latin glyphs) while preserving structural authority:

- **Headlines (Manrope):** Geometric, modern grotesque anatomy with high x-height and open apertures. Retains distinct clarity when paired with bilingual Hindi or Maithili titles (e.g., *गंगुली ग्राम पंचायत*). Large scale sizes adapt smoothly across compact viewport sizes without breaking layout grids.
- **Body & Longform (Source Sans 3):** Engineered for sustained, effortless readability in varied lighting conditions. The humanist proportions accommodate dense civic announcements, legal resolution texts, and utility lists without typographic fatigue.
- **Labels & Micro-copy (Manrope):** Set in semibold and bold weights with subtle positive letter tracking to ensure instant scannability on status pills, scheme IDs, and navigation chips.

## Layout & Spacing

The layout is built mobile-first around Android ergonomic reachability patterns, transitioning upward through fluid constraints for tablet and desktop kiosk contexts.

### Grid & Canvas Structure
- **Mobile Handheld (0–599px):** 4-column fluid layout with `margin: 1rem` and `gutter: 1rem`. Interactive touch targets occupy horizontal full-width or side-by-side modules.
- **Tablet & Foldable (600–1023px):** 8-column layout with `margin-tablet: 2rem` and `gutter-tablet: 1.5rem`. Service categories and feed cards shift into modular multi-column grids.
- **Desktop & Administrative Portal (1024px+):** 12-column layout bounded by a max-width of `1200px` to maintain focused density during data management.

### Rhythm & Vertical Cadence
Spacing follows an exact 4px/8px modular scale. Component interiors enforce a minimum 12px vertical cushion (`space-sm` + `space-xs`), preventing cramped tap areas. Critical operational cards utilize `space-md` internally and `space-md` vertically to separate independent community records.

## Elevation & Depth

Visual hierarchy rejects exaggerated drop shadows in favor of crisp architectural stacking, tailored for daylight viewability on low-to-mid range mobile displays.

- **Level 0 (Flat Ground):** Canvas surface `#F8FAFC`. Zero elevation, pure backdrop.
- **Level 1 (Card & Module Foundation):** Pure white `#FFFFFF` surface bounded by a subtle `1px solid #E2E8F0` hairline border and an ambient structural shadow: `0 1px 3px rgba(15, 23, 42, 0.05), 0 1px 2px rgba(15, 23, 42, 0.03)`.
- **Level 2 (Interactive Elements & Floating Nav):** Used on active cards, bottom sticky action bars, and modal overlays. Hairline border `1px solid #CBD5E1` combined with a soft emerald-tinted shadow: `0 4px 6px -1px rgba(20, 83, 45, 0.06), 0 2px 4px -2px rgba(20, 83, 45, 0.04)`.
- **Level 3 (Modals & Sheet Layers):** System dialogs and drawer menus utilize `0 20px 25px -5px rgba(15, 23, 42, 0.1), 0 8px 10px -6px rgba(15, 23, 42, 0.06)`, anchored over a 40% deep-slate scrim (`#0F172A66`).

## Shapes

The geometric framework balances crisp modern rectangular discipline with distinctive civic badge styling:

- **Soft Base Curve (`roundedness: 1`):** Functional panels, primary structural cards, form inputs, and notifications use a disciplined `0.25rem` (4px) to `0.5rem` (8px for `rounded-lg`) corner radius. This gives an institutional, orderly feel reminiscent of municipal ledger architecture.
- **Pill Exception for Badges & Buttons:** To visually counterbalance the disciplined rectangular containers, all categorical badges, status indicators, and primary action buttons utilize full capsule/pill shaping (`rounded-full` / `9999px`). This deliberate juxtaposition makes operational controls unmistakable and touch-friendly.

## Components

### Buttons
- **Primary:** Full capsule shape, solid `#14532D` background, `#FFFFFF` text, `label-lg` typography. Active/pressed state shifts to `#166534`. Minimum touch height: 48px.
- **Accent / Emergency Action:** Full capsule shape, solid `#EA580C` background, `#FFFFFF` text. Used exclusively for primary submissions, grievance triggers, or critical village announcements.
- **Secondary / Outlined:** Full capsule shape, transparent background, `1.5px solid #14532D`, `#14532D` text.
- **Tonal / Subtle:** Background `#F0FDF4` (Emerald 50), text `#14532D`, zero border.

### Status Indicators & Pill Badges
- **Format:** Fully rounded capsule (`9999px`), horizontal padding `0.75rem`, vertical padding `0.25rem`. Text uses `label-md`.
- **Approved / Active:** `#DCFCE7` background with `#14532D` text, paired with a 6px circular green indicator dot.
- **Pending / In Review:** `#FFEDD5` background with `#EA580C` text, paired with an amber pulsing dot.
- **Emergency / Critical Alert:** `#FEE2E2` background with `#991B1B` text.
- **Wards & Panchayat Badges:** Neutral pill with `#F1F5F9` background, `#334155` text, and a `#CBD5E1` border.

### Modular Cards
- **Base Style:** Surface `#FFFFFF`, border `1px solid #E2E8F0`, corner radius `0.5rem` (`rounded-lg`), internal padding `1rem`.
- **Civic Action Card:** Features a prominent header zone, bold title in `headline-sm`, bilingual metadata tag, and an integrated full-width pill button anchored at the base.
- **Notice Board Card:** Emerald left accent stripe (`4px solid #14532D`), background `#FFFFFF`, accompanied by saffron metadata chips to highlight publication dates and ward numbers.

### Form Inputs & Selectors
- **Input Field:** Minimum height 48px, background `#FFFFFF`, border `1.5px solid #CBD5E1`, corner radius `0.375rem`. Focused state features a sharp emerald border `#14532D` with a subtle outline glow (`rgba(20, 83, 45, 0.15)`).
- **Labels:** Set in `title-md`, dark `#0F172A`, placed above inputs with clear bilingual translation hints in `#64748B`.

### Lists & Feed Items
- **Structure:** Clean rows separated by `1px solid #E2E8F0` hairline dividers.
- **Leading Indicator:** 44px circular or rounded-lg avatar/icon slot rendered in `#F0FDF4` tint with `#14532D` iconography.
- **Trailing Element:** Clear status pill badge or high-contrast directional chevron (`#94A3B8`).

### Village Quick-Services Grid
- 2x4 or 3x3 responsive grid featuring square action tiles. Pure white background, `1px solid #E2E8F0`, topped with emerald `#14532D` utility icons and bottom label in `label-md` (`#0F172A`).